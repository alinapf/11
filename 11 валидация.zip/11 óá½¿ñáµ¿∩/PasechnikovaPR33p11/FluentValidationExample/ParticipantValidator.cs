﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasechnikovaPR33p11.FluentValidationExample
{
    public class ParticipantValidator :AbstractValidator<Participant>
    {
        public ParticipantValidator ()
        {
            RuleFor(p => p.Fullname)
                .NotEmpty( )
                .WithMessage("Имя не может быть пустым")
                .Must(name => name.All(c => char.IsLetter(c) || c == ' ' || c == '-' || c == '\''))
                .WithMessage("Имя может содержать только буквы, дефисы, апострофы и пробелы");
            RuleFor(p => p.Email)
                .EmailAddress( )
                .WithMessage("Введите корректный email адрес");
            RuleFor(p => p.Age)
                .LessThan(110)
                .WithMessage("Возраст не может превышать 110 лет")
                .GreaterThanOrEqualTo(18)
                .WithMessage("Возраст не может быть меньше 18 лет");
            RuleFor(p => p.Phone)
                .Must(name => name.All(c => char.IsNumber(c) || c == '+'))
                .WithMessage("Номер может содержать только цифры")
                .NotEmpty( )
                .WithMessage("Номер не может быть пустым")
                .Matches("(\\+7|8)\\d{10}")
                .WithMessage("Номер должен содержать 11 цифр");
        }
    }
}
