﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasechnikovaPR33p11.Extensions
{
    public static class IsbnExtension
    {
        public static bool IsIsbn10 (this string input)
        {
            if (input.Length == 10)
            {
                int sum = 0;
                int k = 10;
                for (int i = 0; i < 9; i++)
                {
                    sum += (input[i] - '0') * k;
                    k--;
                }
                if (11 - (sum % 11) == input [ 9 ] - '0') return true;
                else return false;
            }
            else
                return false;
        }
    }
}
