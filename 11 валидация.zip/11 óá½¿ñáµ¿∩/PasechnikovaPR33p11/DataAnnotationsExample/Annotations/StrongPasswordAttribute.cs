﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PasechnikovaPR33p11.DataAnnotationsExample.Annotations
{
    public class StrongPasswordAttribute :ValidationAttribute
    {
        public override bool IsValid (object? value)
        {
            string password = value?.ToString( ) ?? string.Empty;
            if (password.Length < 8)
            {
                ErrorMessage = "Укажите надежный пароль Должен содержать больше 8 символов";
                return false;
            }
            
            if (!Regex.IsMatch(password, "[A-Z]"))
            {
                ErrorMessage = "Укажите надежный пароль Должна быть заглавная буква";
                return false;
            }

            if (!Regex.IsMatch(password, "[a-z]"))
            {
                ErrorMessage = "Укажите надежный пароль Должна быть строчная буква";
                return false;
            }

            if (!Regex.IsMatch(password, "[0-9]"))
            {
                ErrorMessage = "Укажите надежный пароль Должна быть одна цифра";
                return false;
            }

            if (!Regex.IsMatch(password, "[!@#$%^&*()*\\-+/.,{}]"))
            {
                ErrorMessage = "Укажите надежный пароль Должен быть спецсимвол";
                return false;
            }
            return true;
        }
    }
}
