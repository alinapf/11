
using PasechnikovaPR33p11.Extensions;

namespace PasechnikovaPR33p11Tests
{
    public class Tests
    {
        [SetUp]
        public void Setup ()
        {
        }

        [Test]
        public void Test1 ()
        {
            Assert.That("2266111566".IsIsbn10(), Is.EqualTo(true));
        }

        [Test]
        public void Test2 ()
        {
            Assert.That("2266111565".IsIsbn10( ), Is.EqualTo(false));
        }

        [Test]
        public void Test3 ()
        {
            Assert.That("22661115".IsIsbn10( ), Is.EqualTo(false));
        }

        [Test]
        public void Test4 ()
        {
            Assert.That("22661115245443".IsIsbn10( ), Is.EqualTo(false));
        }

        [Test]
        public void Test5 ()
        {
            Assert.That("1123121265".IsIsbn10( ), Is.EqualTo(true));
        }
    }
}