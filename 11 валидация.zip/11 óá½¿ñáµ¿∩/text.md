# Механизмы валидации

## 1. Макет главного окна

Создайте проект WPF.

Добавьте в разметку главного окна код:
```xml
<TabControl>
    <TabItem Header="Валидация в обработчике">

	</TabItem>
    <TabItem Header="Использование FluentValidation">

    </TabItem>
    <TabItem Header="Использование аннотаций">

    </TabItem>
    <TabItem Header="Использование ValidationRule">

    </TabItem>
    <TabItem Header="Использование IDataError">

    </TabItem>
</TabControl>
```

Элемент `TabControl` позволяет разбить содержимое по вкладкам. Само содержимое располагается в `TabItem`.

Задайте самостоятельно главному окну свойства `Title`, `Width` и `Height`. Задайте главному окну `WindowStartupLocation="CenterScreen"`.


## 2. Простая проверка условия

Создайте в проекте папку `SimpleEventHandler`. Создайте в папке **пользовательский элемент управления (WPF)** и назовите его `SimpleEventHandlerForm`. Разместите в нем код разметки простой формы:
```xml
    <StackPanel Margin="5">
        <TextBlock Text="Название книги" />
        <TextBox />
        <TextBlock Text="Автор" />
        <TextBox />
        <TextBlock Text="Количество страниц" />
        <TextBox />
        <TextBlock Text="ISBN-10" />
        <TextBox />
        <Button Content="Добавить" Margin="0,10,0,0" />
    </StackPanel>
```

Создайте класс `Book`:
```cs
public class Book
{
    public string Title { get; set; } = string.Empty;
    public string Author { get; set; } = string.Empty;
    public int PagesCount { get; set; }
    public string Isbn10 { get; set; } = string.Empty;
}
```

Задайте `DataContext`:
```xml
<UserControl.DataContext>
    <local:Book />
</UserControl.DataContext>
```

Выполните привязку для соответствующих полей ввода.

Добавьте перед кнопкой `ItemsControl` для вывода ошибок проверки:
```cs
<ItemsControl x:Name="ValidationErrorsList" Margin="0, 10">
    <ItemsControl.ItemTemplate>
        <DataTemplate>
            <TextBlock Foreground="Red" Text="{Binding }" />
        </DataTemplate>
    </ItemsControl.ItemTemplate>
</ItemsControl>
```
Укажем для него `ItemsSource` в коде конструктора пользовательского элемента управления:
```cs
private ObservableCollection<string> errors = new();

public SimpleEventHandlerForm()
{
    InitializeComponent();
    ValidationErrorsList.ItemsSource = errors;
}
```


Добавьте обработчик нажатия на кнопку "Добавить":
```cs
private void AddBook(object sender, RoutedEventArgs e)
{

}
```

В обработчике пропишите проверки:
```cs
private void AddBook(object sender, RoutedEventArgs e)
{
    errors.Clear();
    Book book = (Book)DataContext;

    if (book.Title.Length == 0 || book.Title.Length > 100)
    {
        errors.Add("Укажите длину книги от 1 до 100 символов");
    }

    if (book.Author.Length == 0 || book.Author.Length > 100)
    {
        errors.Add("Укажите авторов книги (от 1 до 100 символов)");
    }

    if (book.PagesCount < 0)
    {
        errors.Add("Количество страниц не может быть отрицательным");
    }

    if (errors.Count > 0)
    {
        MessageBox.Show("Не удалось добавить запись. Проверьте корректность введенных данных");
    }
    else
    {
        MessageBox.Show("Добавлено");
    }
}
```

В главном окне добавьте UserControl:
```xml
xmlns:seh="clr-namespace:ValidationDemo1.SimpleEventHandler"
```
```xml
<TabItem Header="Валидация в обработчике">
    <seh:SimpleEventHandlerForm />
</TabItem>
```

Запустите и убедитесь, что все работает.

Создайте в проекте папку `Extensions`. В папке создайте класс:
```cs
public static class IsbnExtension
{
    public static bool IsIsbn10(this string input)
    {
        throw new NotImplementedException();
    }
}
```

Добавьте в коде `AddBook` проверку Isbn10:
```cs
if (!book.Isbn10.IsIsbn10())
{
    errors.Add("Укажите действительный isbn-10");
}
```

Создайте в решении еще один проект (тестовый проект, `NUnit`). Назовите его также, как и основной, но добавьте к нему `Tests`. Свяжите тестовый проект с основным. Определите тестовый класс:
```cs
    public class IsbnTests
    {
    	//...
    }
```
В случае, если возникнет проблема с совместимостью проектов, укажите в свойствах тестового проекта значение "Целевая ОС" равным `Windows`.

#### Самостоятельная работа
- укажите `TextBox` максимальную длину строк;
- любым удобным способом добейтесь того, чтобы в поле ввода количества нельзя было вводить не цифры, или просто добавьте дополнительную проверку значения с помощью `TryParse`;
- реализуйте метод `Isbn10`;
- для метода `Isbn10` напишите набор модульных тестов.

Информацию про Isbn10 можно найти на Википедии.

## 3. FluentValidation

FluentValidation - популярная библиотека для осуществления валидации. Реализуем проверку значений с ее помощью.

Создайте папку `FluentValidationExample`. В папке создайте User Control (аналогично пункту 2) и назовите его `FluentValidationForm`. Создайте форму:
```cs
<StackPanel Margin="5">
    <TextBlock Text="Полное имя участника" />
    <TextBox />
    <TextBlock Text="Email" />
    <TextBox />
    <TextBlock Text="Номер телефона" />
    <TextBox />
    <TextBlock Text="Возраст" />
    <TextBox />
    <ItemsControl x:Name="ValidationErrorsList" Margin="0, 10">
        <ItemsControl.ItemTemplate>
            <DataTemplate>
                <TextBlock Foreground="Red" Text="{Binding }" />
            </DataTemplate>
        </ItemsControl.ItemTemplate>
    </ItemsControl>
    <Button Content="Добавить" Margin="0,10,0,0" />
</StackPanel>
```

Создайте также класс:
```cs
public class Participant
{
    public string Fullname { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public int Age { get; set; }
}
```

Определите `DataContext`:
```xml
<UserControl.DataContext>
    <local:Participant />
</UserControl.DataContext>
```

Выполните привязку соответствующих свойств.

Установите пакет `FluentValidation`.

Создайте класс `ParticipantValidator`.

Чтобы использовать `FluentValidation` необходимо проделать следующее:
- создать класс и унаследовать его от `AbstractValidator<T>`;
- прописать в классе правила для валидации с помощью "текучего" (fluent) интерфейса;
- создать экземпляр класса и использовать его в коде.

Код `ParticipantValidator` будет следующим:

```cs
public class ParticipantValidator : AbstractValidator<Participant>
{
    public ParticipantValidator()
    {
        RuleFor(p => p.Fullname)
            .NotEmpty()
            .WithMessage("Имя не может быть пустым")
            .Must(name => name.All(c => char.IsLetter(c) || c == ' ' || c == '-' || c == '\''))
            .WithMessage("Имя может содержать только буквы, дефисы, апострофы и пробелы");
        RuleFor(p => p.Email)
            .EmailAddress()
            .WithMessage("Введите корректный email адрес");
        RuleFor(p => p.Age)
            .LessThan(110)
            .WithMessage("Возраст не может превышать 110 лет")
            .GreaterThanOrEqualTo(18)
            .WithMessage("Возраст не может быть меньше 18 лет");
    }
}
```

С помощью метода `RuleFor` мы задаем правила. С помощью методов, которые вызываются по цепочке эти правила кастомизируются. Добавьте **самостоятельно** правило для номера телефона. Используйте методы `Matches` (принимает параметром регулярное выражение) и `WithMessage`.


Добавьте в контроле поле для ошибок валидации:
```cs
private ObservableCollection<string> errors = new();

public FluentValidationForm()
{
    InitializeComponent();
    ValidationErrorsList.ItemsSource = errors;
}
```

Создайте обработчик нажатия на кнопку `AddParticipant`:
```cs
private void AddParticipant(object sender, RoutedEventArgs e)
{
    errors.Clear();
    var participant = (Participant)DataContext;

    var validator = new ParticipantValidator();
    var result = validator.Validate(participant);
    
    if (result.IsValid)
    {
        MessageBox.Show("Запись добавлена!");
    }
    else
    {
        result.Errors.ForEach(err => errors.Add(err.ErrorMessage));
    }
}
```

Добавьте `UserControl` в разметке в `MainWindow` и проверьте работоспособность.

## 4. Использование аннотаций

Создайте папку `DataAnnotationsExample` и пользовательский элемент `DataAnnotationsForm`. 
Напишите код разметки:
```xml
   <StackPanel Margin="5">
       <TextBlock Text="Имя пользователя" />
       <TextBox />
       <TextBlock Text="Электронная почта" />
       <TextBox  />
       <TextBlock Text="Пароль" />
       <TextBox />
       <TextBlock Text="Повторите пароль" />
       <TextBox />
       <ItemsControl x:Name="ValidationErrorsList" Margin="0, 10">
           <ItemsControl.ItemTemplate>
               <DataTemplate>
                   <TextBlock Foreground="Red" Text="{Binding }" />
               </DataTemplate>
           </ItemsControl.ItemTemplate>
       </ItemsControl>
       <Button Content="Добавить" Margin="0,10,0,0" />
   </StackPanel>
```

Создайте класс `UserInfo`:
```cs
public class UserInfo
{
    [Required(ErrorMessage = "Укажите имя")]
    [RegularExpression(@"[a-zA-Z0-9_]+", 
        ErrorMessage = "Имя пользователя может содержать только латинские буквы, цифры и символ подчеркивания")]
    public string Username { get; set; } = string.Empty;

    [EmailAddress(ErrorMessage = "Введите корректный Email")]
    public string Email { get; set; } = string.Empty;

    [MinLength(8)]
    public string Password { get; set; } = string.Empty;

    [Compare(nameof(Password), ErrorMessage = "Пароли не совпадают")]
    public string RepeatPassword { get; set; } = string.Empty;
}
```

Задайте DataContext:
```xml
    <UserControl.DataContext>
        <local:UserInfo />
    </UserControl.DataContext>
```

Выполните привязку свойств.

Добавьте в коде контрола поле для вывода списка ошибок:
```cs
private ObservableCollection<string> errors = new();

public DataAnnotationsForm()
{
    InitializeComponent();
    ValidationErrorsList.ItemsSource = errors;
}
```

Напишите обработчик события для нажатия на кнопку:
```cs
private void AddUser(object sender, RoutedEventArgs e)
{
    errors.Clear();
    var user = (UserInfo)DataContext;
    ValidationContext context = new(user);
    List<System.ComponentModel.DataAnnotations.ValidationResult> results = new();
    bool isValid = Validator.TryValidateObject(user, context, results, true);

    if (isValid)
    {
        MessageBox.Show("Добавлено!");
    }
    else
    {
        foreach (string error in results.Select(r => r.ErrorMessage ?? string.Empty))
        {
            errors.Add(error);
        }
    }
}
```

Добавьте созданный элемент в код главного окна и проверьте результат.

Создайте каталог `Annotations`. Создайте в нем класс `StrongPasswordAttribute`:
```cs
public class StrongPasswordAttribute : ValidationAttribute
{
    public override bool IsValid(object? value)
    {
        string password = value?.ToString() ?? string.Empty;
        if (password.Length < 8)
        {
            ErrorMessage = "Укажите надежный пароль";
            return false;
        }
        return true;
    }
}
```

Это позволит нам создать свою аннотацию данных (достаточно унаследоваться от `ValidationAttribute` и переписать вирутальный метод `IsValid`).

Измените аннотацию для свойства `Password` класса `UserInfo`:
```cs
[StrongPassword]
public string Password { get; set; } = string.Empty;
```

Запустите и проверьте, что все работает.

#### Самостоятельная работа

Измените код метода `IsValid` таким образом, чтобы сильный пароль обязательно содержал:
- буквы в нижем и верхнем регистре;
- цифру;
- спецсимвол.

Создайте в тестовом проекте набор тестов для проверки метода `IsValid`.

## 5. Validation Rules

Создайте папку `ValidationRulesExample` и элемент `ValidationRulesForm`.

Определите разметку:
```xml
<StackPanel Margin="5">
    <TextBlock Text="Название товара" />
    <TextBox />
    <TextBlock Text="Цена" />
    <TextBox />
    <TextBlock Text="Количество" />
    <TextBox />
    <TextBlock Text="Описание" />
    <TextBox Height="100" AcceptsReturn="True" TextWrapping="Wrap" />
    <Button Content="Добавить" Margin="0,10,0,0" />
</StackPanel>
```

Создайте класс:
```cs
public class Product
{
    public string Name { get; set; } = string.Empty;
    public int Price { get; set; }
    public int Count { get; set; }
    public string? Description { get; set; }
}
```

Задайте DataContext:
```cs
<UserControl.DataContext>
    <local:Product />
</UserControl.DataContext>
```

Выполните привязку.

Создайте класс `PositiveValidationRule`, унаследуйте его от `ValidationRule` и используйте быстрые действия "реализовать абстрактный класс"
```cs
public class PositiveValidationRule : ValidationRule
{
    public override ValidationResult Validate(object value, CultureInfo cultureInfo)
    {

    }
}
```

Реализуем логику проверки:
```cs
public class PositiveValidationRule : ValidationRule
{
    public override ValidationResult Validate(object value, CultureInfo cultureInfo)
    {
        if (int.TryParse(value.ToString(), out int number))
        {
            if (number >= 0)
            {
                return ValidationResult.ValidResult;
            }
            return new ValidationResult(false, $"Значение {number} является отрицательным");
        }
        return new ValidationResult(false, "Укажите корректное целое число");
    }
}
```

Используем правило, расписав привязки:
```xml
<TextBox>
    <TextBox.Text>
        <Binding Path="Price">
            <Binding.ValidationRules>
                <local:PositiveValidationRule />
            </Binding.ValidationRules>
        </Binding>
    </TextBox.Text>
</TextBox>
<TextBlock Text="Количество" />
<TextBox>
    <TextBox.Text>
        <Binding Path="Count">
            <Binding.ValidationRules>
                <local:PositiveValidationRule />
            </Binding.ValidationRules>
        </Binding>
    </TextBox.Text>
</TextBox>
```

Добавьте в MainWindow созданный элемент. Запустите и убедитесь, что если ввести отрицательное число и перевести фокус, то вокруг поля ввода появится красная рамка.

Добавьте `ItemsControl` для вывод сообщений об ошибках:
```xml
<TextBlock Text="Цена" />
<TextBox x:Name="PriceTextBox">
    <TextBox.Text>
        <Binding Path="Price">
            <Binding.ValidationRules>
                <local:PositiveValidationRule />
            </Binding.ValidationRules>
        </Binding>
    </TextBox.Text>
</TextBox>
<ItemsControl ItemsSource="{Binding ElementName=PriceTextBox, Path=(Validation.Errors)}">
    <ItemsControl.ItemTemplate>
        <DataTemplate>
            <TextBlock Text="{Binding ErrorContent}" Foreground="Red" />
        </DataTemplate>
    </ItemsControl.ItemTemplate>
</ItemsControl>
```
Запустите и проверьте, что появляется сообщение.

Добавьте обработчик по нажатию на кнопку:
```cs
private void AddProduct(object sender, RoutedEventArgs e)
{
    var priceErrors = Validation.GetErrors(PriceTextBox);

    if (priceErrors.Count > 0)
    {
        MessageBox.Show("Ошибка при добавлении, проверьте корректность данных");
        return;
    }

    MessageBox.Show("Успех!");
}
```

Запустите и проверьте работоспособность.

#### Самостоятельная работа

- реализуйте аналогичную проверку значения для количества товара;
- добавьте правило `NotEmptyValidationRule` (название не может быть пустым) и установите его для названия;
- добавьте правило `TitleValidationRule` (название содержит только буквы, цифры, пробелы и символ кавычки `"`, например ООО "Ромашка");
- задайте правила для названия и реализуйте проверку в `AddProduct`.

## 6. Интерфейс IDataError

**Самостоятельная работа.**

Создайте папку `IDataErrorExample` и элемент `IDataErrorForm`.

Создайте класс:
```cs
public class Course
{
	public string Name { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
    public decimal Price { get; set; }
}
```

Реализуйте форму для добавления курса. Изучите с помошью материалов Internet принципы работы интерфейса IDataError, и используйте его для валидации значений вашей формы.

Считаем, что название курса может содержать от 2 до 100 символов. Дата начала курса не может быть больше, чем дата окончания курса. Дата начала курса не может быть меньше, чем 01.01.2020. Цена курса не может быть отрицательной.